# Responsive Challenge: Dawg Coffee

This folder contains your submission for the [responsive challenge](http://faculty.washington.edu/mikefree/info343/#/challenges/responsive). The below questions should be answered with details about your submission!

##### 1. What is the URL of this site, as hosted on your student webserver (i.e., students.washington.edu/<code>{uw-new-id}</code>/info343/<code>{project-name}</code>) #####
> Answer goes here!
https://github.com/hiiamhuy/dawg-coffee.git
http://students.washington.edu/hiiamhuy/info343/dawg-coffee/
##### 2. Did you receive any help from others (classmates, etc)? If so, please list who. #####
> Answer goes here!
No. The only help was TA and in class time with students around.
##### 3. Did you complete any advanced extensions to this challenge? If so, what? #####
> Answer goes here!
NOPE! 
##### 4. Approximately how many hours did it take you to complete this challenge? #####
> Answer goes here!
Spent way to much.... OVER 9000! Most likely 18 - 20 that SVG... 
##### 5. Did you encounter any problems in this challenge we should warn students about in the future? How can we make the challenge better? #####
> Answer goes here!
Tell us to open the SVG file... TOO LONG! make it shorter? 
